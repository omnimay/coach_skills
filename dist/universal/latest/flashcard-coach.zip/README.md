# 深维智讯・学习闪卡

> 学习闪卡是一种 AI 驱动的知识学习工具。将产品资料、课程文档或知识主题快速生成学习闪卡，支持选择题、问答题、朗读背诵等练习方式，帮助你快速掌握和巩固重点知识。支持 AI 出题、改题和调整题目数量。

## 概述

深维智讯・学习闪卡 是一个 MCP 技能包，包含以下技能：

- **coach-mcp-connect**: MCP 连接诊断与恢复。当 MCP 工具不可用时，调用此技能恢复连接。
- **flashcard_design**: 通过 OmniMay MCP 工具对话式创建/编辑闪卡（考官V2）课程，支持上传文档作为出题素材。自动根据用户权限路由权限分叉（管理员=编辑链接 / 学员=自动练习）。触发：用户要建闪卡课/考官课/出题/改题数/基于文档出题。

## 安装指南

### 1. 下载并解压

从 OSS 下载 ZIP 文件并解压到本地目录：

```bash
# 下载（示例 URL）
curl -L -o flashcard.zip https://example.com/flashcard.zip

# 解压
unzip flashcard.zip -d flashcard
```

### 2. 配置 MCP 客户端

将 `mcp.json` 的内容合并到你的 MCP 客户端配置中。

**Claude Code 配置示例**：

编辑 `~/.claude.json`，在 `mcpServers` 中添加：

```json
{
  "mcpServers": {
    "mgv-flashcard": {
      "type": "streamableHttp",
      "url": "https://mcp.omnimay.com/coach/mcp"
    }
  }
}
```

**Cursor 配置示例**：

编辑 `.cursor/mcp.json`（项目级）或 `~/.cursor/mcp.json`（全局），添加相同的配置。

### 3. 验证连接

启动你的 MCP 客户端，检查技能是否已加载。

如果使用 Claude Code，运行：
```bash
claude mcp list
```

应该能看到 `深维智讯・学习闪卡` 相关的技能。

## 技能列表

### coach-mcp-connect

MCP 连接诊断与恢复。当 MCP 工具不可用时，调用此技能恢复连接。

### flashcard_design

通过 OmniMay MCP 工具对话式创建/编辑闪卡（考官V2）课程，支持上传文档作为出题素材。自动根据用户权限路由权限分叉（管理员=编辑链接 / 学员=自动练习）。触发：用户要建闪卡课/考官课/出题/改题数/基于文档出题。

## 故障排查

### MCP 工具不可用

如果 MCP 工具无法使用，请检查：

1. **配置文件语法**：确保 JSON 格式正确
2. **MCP Server URL**：确认 URL 可访问
3. **认证信息**：如果需要 token，确保已正确配置

### 技能未加载

如果技能未出现在客户端中：

1. 检查 `mcp.json` 是否已正确合并到客户端配置
2. 重启 MCP 客户端
3. 查看客户端日志，确认无错误信息

### 连接诊断

使用 `coach-mcp-connect` 技能进行连接诊断（如果包中包含此技能）。

## 支持的 MCP 客户端

- Claude Code（CLI）
- Cursor
- Continue.dev
- 其他兼容 MCP 协议的客户端

## 更多信息

- 项目仓库：https://github.com/example/flashcard
- 问题反馈：https://github.com/example/flashcard/issues
