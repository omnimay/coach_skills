# 深维智讯·课程推荐

> 从录音分析、复盘总结等任意分析报告提取学员短板，自动匹配或创建培训课程，经确认后向指定学员批量下发培训任务并飞书通知。

## 概述

深维智讯·课程推荐 是一个 MCP 技能包，包含以下技能：

- **ai_customer_design**: 创建和修改公司培训课程、上传课程资料、查询课程并生成练习链接。触发关键词：建课、AI 客户课程、AI 设计师对话、改课、查询培训课程、生成练习链接。
- **coach-mcp-connect**: MCP 连接诊断与恢复。当 MCP 工具不可用时，调用此技能恢复连接。
- **flashcard_design**: 通过 OmniMay MCP 工具对话式创建/编辑闪卡（考官V2）课程，支持上传文档作为出题素材。自动根据用户权限路由权限分叉（管理员=编辑链接 / 学员=自动练习）。触发：用户要建闪卡课/考官课/出题/改题数/基于文档出题。
- **recommend_courses**: 处理任意分析报告并下发培训任务：从录音分析、复盘总结、能力评估等报告中提取学员短板、按标签匹配课程、无匹配时委托建课并打标、向指定学员批量下发任务。触发关键词：分析报告、总结报告、复盘、录音分析、能力评估、短板、培训任务下发、批量下发任务、培训闭环。

## 安装指南

### 1. 下载并解压

从 OSS 下载 ZIP 文件并解压到本地目录：

```bash
# 下载（示例 URL）
curl -L -o recommend-courses.zip https://example.com/recommend-courses.zip

# 解压
unzip recommend-courses.zip -d recommend-courses
```

### 2. 配置 MCP 客户端

将 `mcp.json` 的内容合并到你的 MCP 客户端配置中。

**Claude Code 配置示例**：

编辑 `~/.claude.json`，在 `mcpServers` 中添加：

```json
{
  "mcpServers": {
    "enterprise-training": {
      "type": "streamableHttp",
      "url": "https://aicoach.eapps.dingtalkcloud.com/omnimay/coach/mcp"
    }
  }
}
```

**Cursor 配置示例**：

编辑 `.cursor/mcp.json`（项目级）或 `~/.cursor/mcp.json`（全局），添加相同的配置。

### 3. 验证连接

启动你的 MCP 客户端，检查技能是否已加载。

如果使用 Claude Code，运行：
```bash
claude mcp list
```

应该能看到 `深维智讯·课程推荐` 相关的技能。

## 技能列表

### ai_customer_design

创建和修改公司培训课程、上传课程资料、查询课程并生成练习链接。触发关键词：建课、AI 客户课程、AI 设计师对话、改课、查询培训课程、生成练习链接。

### coach-mcp-connect

MCP 连接诊断与恢复。当 MCP 工具不可用时，调用此技能恢复连接。

### flashcard_design

通过 OmniMay MCP 工具对话式创建/编辑闪卡（考官V2）课程，支持上传文档作为出题素材。自动根据用户权限路由权限分叉（管理员=编辑链接 / 学员=自动练习）。触发：用户要建闪卡课/考官课/出题/改题数/基于文档出题。

### recommend_courses

处理任意分析报告并下发培训任务：从录音分析、复盘总结、能力评估等报告中提取学员短板、按标签匹配课程、无匹配时委托建课并打标、向指定学员批量下发任务。触发关键词：分析报告、总结报告、复盘、录音分析、能力评估、短板、培训任务下发、批量下发任务、培训闭环。

## 故障排查

### MCP 工具不可用

如果 MCP 工具无法使用，请检查：

1. **配置文件语法**：确保 JSON 格式正确
2. **MCP Server URL**：确认 URL 可访问
3. **认证信息**：如果需要 token，确保已正确配置

### 技能未加载

如果技能未出现在客户端中：

1. 检查 `mcp.json` 是否已正确合并到客户端配置
2. 重启 MCP 客户端
3. 查看客户端日志，确认无错误信息

### 连接诊断

使用 `coach-mcp-connect` 技能进行连接诊断（如果包中包含此技能）。

## 支持的 MCP 客户端

- Claude Code（CLI）
- Cursor
- Continue.dev
- 其他兼容 MCP 协议的客户端

## 更多信息

- 项目仓库：https://github.com/example/recommend-courses
- 问题反馈：https://github.com/example/recommend-courses/issues
