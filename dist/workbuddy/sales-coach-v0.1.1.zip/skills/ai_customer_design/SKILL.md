---
name: ai_customer_design
description: 创建和修改公司培训课程、上传课程资料、查询课程并生成练习链接。触发关键词：建课、AI 客户课程、AI 设计师对话、改课、查询培训课程、生成练习链接。
metadata:
  description_zh: 创建和修改公司培训课程，上传资料并生成练习入口。
  description_en: Create and edit company training courses and generate practice links.
---

# 公司培训课程技能（ai_customer_design）

通过宿主 MCP 客户端连接企业培训服务（enterprise-training），执行建课、改课、文档上传、查询等操作，并交付练习链接与二维码。

## 前提

- 宿主 MCP 客户端已连接 enterprise-training 服务，连接与 OAuth 授权由宿主管理
- **流式脚本认证**（按优先级尝试）：
  1. **从宿主 MCP 配置获取 bearer_token**：检查宿主对此 MCP 服务的配置，取其中的 token → `export MCP_BEARER_TOKEN=<token>`
  2. **OAuth 登录**（需要浏览器，部分环境可能不支持）：`<PYTHON_CMD> mcp_client.py auth`
  - 首次使用先 `<PYTHON_CMD> mcp_client.py auth --status` 校验
- 工具名称前缀以宿主实际 tools/list 为准（如 `training.course.create_ai_customer`）
- 业务数据在工具返回的 structuredContent 顶层，无 `.data` 信封

**跨平台 Python 命令**（Windows 下 `python3` 可能是失效的 WindowsApps 别名）：
```bash
# 先探测可用命令
python --version || py --version || python3 --version
```
后续示例中 `<PYTHON_CMD>` 指代上述探测到的命令。

## 建课流程

### Step 1：创建课程

`course.create_ai_customer({"categoryId":0})` → 拿到 courseId

### Step 2：与 AI 设计师对话

通过流式脚本与 AI 对话（服务端耗时 5-6 分钟，命令行实时展示进度）。

**流式输出编码**（Windows 终端 GBK/UTF-8 错乱时）：
- 优先：`--out result.jsonl` 落盘后读取（避免管道编码问题）
- 或：设置环境变量 `PYTHONIOENCODING=utf-8` 后再调用
- 脚本内部已强制 UTF-8（`mcp_client.py` L44），但 Windows 终端代码页可能覆盖

```bash
<PYTHON_CMD> <bundle_root>/skills/coach-mcp-connect/scripts/mcp_client.py stream --progress-stdout \
  training.course.edit_ai_customer_chat \
  '{"courseId":<id>,"message":"<课程简报>","stream":true}'
```

脚本通过 stdout 输出 `💬` AI 话语 + `📊` 阶段标题 + 终态 JSON。首次使用需认证（优先 bearer_token，或 `mcp_client.py auth`）。

> 调用期间不做中途动作，等待终态 result。进度实时展示给客户端。
> `终态唯一`：判定依据只有终态 result，不基于流中内容做决策。

**终态分流**：

- **计划轮是默认预期**：第一轮 AI 几乎必然只出计划卡片，config 停在 `prepare` 且 `stages` 为空 → 发送 `"确认，开始生成"` 再调一次 chat（第二轮才是真正的生成轮）
- AI 提问 → 组织答案再调一次 chat（同一步骤，`stream:true`）
- AI 说计划供确认 → 发送 `"确认，开始生成"` 再调一次 chat
- error「结果不确定」→ **`不重放`** chat，直接进 Step 3 核实
- 秒拒 / 其他 error → 按 [异常排查](references/troubleshooting.md) 分流
- 本地超时/断流 ≠ 失败，服务端后台继续处理，直接进 Step 3 核实

### Step 3：双完成判定

`course.get_ai_customer_config({"courseId":<id>})`

- `create_status_created` 且 `stages` 非空 → 建课完成，进 Step 4
- 否则（`prepare` / `streaming` / stages 为空）→ 终态到手后先查一次 config，未完成再进轮询兜底（每 30 秒一次，**最长 20 分钟，全程静默不询问用户**）；20 分钟仍未完成则向用户报告

### Step 4：生成练习链接

`task.create_open_project({"courseId":<id>})` → 拿到 link

### Step 5：交付

**同一条回复中**同时给出：

1. 可复制的纯文本链接
2. 二维码：`<PYTHON_CMD> <skill-root>/scripts/render_qr.py '<练习链接>'`

QR 生成失败时直接向用户展示原始练习链接，说明二维码步骤失败。

## 关键业务规则

### 操作状态与允许动作（权威规则）

> **核心规则：发送成功（无报错）就 `不重放` chat，无论结果是否确定。**

| 状态 | 允许动作 | 禁止动作 |
|------|----------|----------|
| 等待用户决策 | 补充信息或确认 | 重发 chat |
| 已受理、执行中 | 查询状态 | 重发 chat |
| 发送成功、结果不确定 | 查询核实 | **重发 chat**（会触发会话锁死） |
| 发送成功、目标已满足 | 交付结果（含原本已满足） | 重发 chat |
| 发送成功、字段未变 | 确认目标是否已满足，交付或报告 | 重发 chat（字段未变 ≠ 失败） |
| 发送失败（报错） | 按错误类型决定是否重试 | 盲目重发 |

**关键判断**：
- 字段发生变化 ≠ 满足用户要求（可能改错了）
- 字段没有变化 ≠ 失败（目标可能原本就已满足）
- 验收应检查**目标条件成立且无意外变更**，而不只是比较前后是否不同

### 5 条核心红线

1. **`config 唯一`**：`status: completed` 或 AI 回复文字不能证明课程建成；唯一判据是 `get_ai_customer_config` 返回 `create_status_created` 且 `stages` 非空。**`config 唯一`**：只信 config 字段值，不信 AI 回复文字。（详解见 [result-and-progress.md](references/result-and-progress.md#两种完成的 distinction)）
2. **`不重放`**：`edit_ai_customer_chat` 发送成功后**`不重放`**（可能触发会话保护锁死）；超时/断流/结果不确定时只通过轮询 `get_ai_customer_config` 核实状态。
3. **fileIds 原样传递**：用户已提供原始文档时，必须走 `file.upload_document` 上传整份文档，把 fileId 经 `metadata.fileIds` 附到 chat；禁止把文档内容摘录为纯文字经 message 传入。**DOCX/PPTX/XLSX 文件若体积较大或上传后解析失败（parseStatus=3），均可先转成 Markdown（.md）再上传**，MD 是纯文本，服务端解析稳定。（详解见 [file-upload.md](references/file-upload.md)）
4. **改课基线核实**：改课前先 `get_ai_customer_config` 记录各字段实际值（基线），改课后再次读取核实字段确实变化；不能只信 AI 自称"配置已满足要求"。
5. **链接 + 二维码双交付**：练习链接与二维码缺一不可，同一回复中交付；QR 生成失败时链接仍是有效交付。
