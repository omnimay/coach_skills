> 迁移自源技能 §course.edit_ai_customer_chat 的本质、§流式输出（SSE）支持、§流式通知类型与终态判定、§建课完成的判断标准、§chat 调用解析契约、§已知约定，业务规则以本文为准

# 结果核实与进度语义

## chat 的本质：对话窗口，不是传统 API

`course.edit_ai_customer_chat` 是和**建课 AI 助手**的**对话窗口**——发一条消息，读懂回复，决定下一步。

## 两种"完成"的区别（⚠️ 极易混淆）

**Operation 完成 ≠ 课程创建完成**

| 概念 | 含义 | 判断方式 | 常见误导 |
|---|---|---|---|
| **Operation 完成** | AI 助手完成了本轮对话 | 调用返回 `status: "completed"` | AI 可能只是提问、生成计划、或确认需求 |
| **课程创建完成** | 课程真正创建成功 | `get_ai_customer_config` 返回 `status="create_status_created"` 且 `stages.length > 0` | 无 |

### 流式调用的响应陷阱

```json
{
  "status": "completed",
  "message": "建课完成",
  "operation_id": "xxx"
}
```

- `status: "completed"` 只表示 AI 助手完成了**本轮对话**
- `message: "建课完成"` 只是 AI 说的话，可能具有误导性
- **这不代表课程已经创建！**

### 正确的判断逻辑（唯一判断标准）

```javascript
const config = await call_tool('training.course.get_ai_customer_config', {courseId});
const isCreated = config.status === 'create_status_created' && config.stages.length > 0;
```

必须验证的字段：

- ✅ `status === "create_status_created"`
- ✅ `stages.length > 0`
- ✅ `evaluates.length > 0`（通常）

**不要依赖**：

- ❌ 调用返回的 `status` 字段
- ❌ AI 助手的回复文字（"建课完成"、"课程已生成"等）
- ❌ Operation 的状态

### AI 助手的回复具有误导性（实测发现）

| AI 回复 | 实际状态 | 说明 |
|---|---|---|
| "建课完成" | `status="create_status_prepare"` | AI 只是完成了对话，还没创建课程 |
| "课程已生成" | `stages=[]` | AI 在描述计划，不是实际创建 |
| "配置已满足要求" | 字段值未变 | AI 幻觉，实际未修改 |

**原则：只信 `get_ai_customer_config` 的字段值，不信 AI 回复文字。**

## 流式调用支持

两层协作：请求带 `stream:true` 开流 + 调用方接收进度通知。**流式内容是给用户看的**（实时展示）；调用方判定只看调用结束后的**终态 result**。

### 两种调用路径

| 路径 | 说明 | 进度展示方式 |
|---|---|---|
| **流式脚本**（`mcp_client.py stream --progress-stdout`） | 主流程使用（见 SKILL.md §建课流程 Step 2） | 命令行 stdout 实时渲染 💬/📊 进度 |

流式脚本位于 bundle 内 `skills/coach-mcp-connect/scripts/mcp_client.py`（详细使用说明见 `coach-mcp-connect/SKILL.md`）。

### 请求与通知

**① 请求侧（开流）**：

```json
{
  "courseId": 123,
  "message": "创建药品销售课程",
  "stream": true
}
```

**② 通知侧**：流式调用期间，建课全程的进度通知由流式脚本实时展示在命令行上——**用户**看到 AI 正文逐字流出与阶段推进；**调用方**只有调用结束后拿到终态 result，不得声称在流中途中途决策。通知 `message` 三类形态：

| message 形态 | 含义 | 用户视角 |
|---|---|---|
| `请求已接受`（首帧） | accepted：后端已受理本次请求 | 知道请求已受理 |
| `[message] xxx`（前缀） | AI 助手话语 delta（实时预览，可丢失） | 实时看到 AI 正文 |
| 其他（如 `自动测试 5%`、`课程计划已生成`） | 阶段标题 | 知道进行到哪一步 |

**流式 vs 非流式**：

- **流式（`stream=true`）**：用户通过脚本 stdout 实时看到进度通知，调用方拿终态 result 判定——建课/改课一律用它
- **非流式（`stream=false`，默认）**：阻塞等待 AI 完整响应，约 60-120s 必超时（后台继续处理），且用户全程看不到过程——仅适合简单问答

## 终态判定（调用方的唯一判定入口）

调用结束后的 `result`，业务数据在 `structuredContent` 顶层：

| 终态形态 | 特征 | 判定与动作 |
|---|---|---|
| complete（`isError:false`） | 计划轮：`{"status":"completed","message":"本轮回复已完成","course_id":..,"operation_id":..}`；生成轮可能含 `response` 字段（权威 AI 回复正文） | **本轮对话完成**。注意 `status:"completed"` ≠ 课程创建完成！若有 `response` 字段，以它为 AI 回复正文向用户展示（UI 流中的 delta 只是用户侧预览）。随后走权威验证 |
| error 终态「结果不确定」 | `{"message":"结果不确定"}`，`isError:true`，无 status/operation_id | **非标准终态但课程通常已建成**（实测多次）。**绝不重试 chat**（会触发会话保护锁死），直接查 `get_ai_customer_config` 判定课程实际状态（E-MCP-UNCERTAIN） |
| error 终态「上游服务暂时不可用」 | <1s 秒回 | 按 troubleshooting.md「三种不可用」鉴别表分流（冷却期/会话锁死/网关故障） |
| error 终态「工具参数无效」 | <1s 秒回，发生在 MCP 网关参数校验层，未触达后端会话，无副作用 | 检查参数：**禁止传 `requestId`**（不是 MCP 工具 schema 字段，`additionalProperties:false` 秒拒）；对照常用工具表 |

## percent 语义（务必纠正直觉）

- percent 是**通知序号，不是完成百分比**——后端串行 writer 每请求从 1 开始单调递增，不封顶（实测确认轮自动测试 100% 时 percent=256，收尾后到 368）
- 唯一的真实百分比在**阶段标题文本**里（`自动测试 0%→100%`）
- percent 严格递增 = 链路健康；序号可用来检测丢帧（连续性缺口）和停滞

## 流式通知与权威验证的边界

三层各答一个问题，互不替代：

| 信息层 | 回答的问题 |
|---|---|
| 流式通知（用户界面可见） | 「调用进行得怎样」——受理了没、AI 在说什么、链路死没死 |
| 终态 result | 「本轮操作结果如何」 |
| `get_ai_customer_config` | 「课程建成了没」 |

终态 result 到手 = 本轮 chat 操作结束（可立即决定下一步），但**建课完成的最终判定永远走 config 验证**。

## 响应数据位置与错误封装

- 业务数据在 `result.structuredContent` **顶层**（如 `{"count":..,"courseList":[..]}`、`{"courseId":..}`），**无 `.data` 信封**；拿不准就先查看原始 JSON 自查，不凭回复文字判断
- 错误时 structuredContent 为 null，错误 msg 在 `result.content[0].text`
- 后端业务错误一律封装为 `isError: true` + 原始 msg（网关错误码 slug 仅覆盖认证过期/账号禁用/限流三类，业务错误分类依赖 msg 文本内容判断）
- 字段转换：后端 snake_case 字段经服务自动转 camelCase；少数工具不加此配置保持原样
- 鉴权透传：工具调用自动使用当前授权用户的凭据，不需额外传

## chat 参数 schema 红线

`edit_ai_customer_chat` 顶层仅允许 `stream/message/courseId/metadata` 四字段（`additionalProperties:false`）。后端 HTTP VO 的 `requestId` 等字段不透出，传了即被网关秒拒「工具参数无效」（无副作用，删掉重试即可）。

## 实测经验标注（M07）

本文量化经验（percent=256/368 实测值、60-120s 非流式必超时、「结果不确定」时课程通常已建成、84s 后台完成等）适用日期 **2026-09-14**，**测试环境（服务版本未记录）**，为阶段性实测结论，不得直接断言为服务端确定行为；生产环境或服务升级后需复测更新。
