---
name: ai_customer_design
description: 创建和修改公司培训课程、上传课程资料、查询课程并生成练习链接。触发关键词：建课、AI 客户课程、AI 设计师对话、改课、查询培训课程、生成练习链接。
metadata:
  description_zh: 创建和修改公司培训课程，上传资料并生成练习入口。
  description_en: Create and edit company training courses and generate practice links.
---

# 公司培训课程技能（ai_customer_design）

通过宿主 MCP 客户端连接企业培训服务（enterprise-training），执行建课、改课、文档上传、查询等操作，并交付练习链接与二维码。

## 适用场景

- 创建培训课程：通过 AI 设计师对话生成课程
- 修改已有课程：调整角色、阶段、评分维度等
- 查询培训数据：课程列表、学员练习明细
- 上传课程资料、生成练习链接

## 前提

- 宿主 MCP 客户端已连接 enterprise-training 服务，连接与 OAuth 授权由宿主管理
- 工具名称前缀以宿主实际 tools/list 为准（如 `training.course.create_ai_customer`）
- 业务数据在工具返回的 structuredContent 顶层，无 `.data` 信封

## 建课流程

### Step 1：创建课程

`course.create_ai_customer({"categoryId":0})` → 拿到 courseId

### Step 2：与 AI 设计师对话

通过流式脚本与 AI 对话（服务端耗时 5-6 分钟，命令行实时展示进度）：

```bash
python3 <bundle_root>/skills/coach-mcp-connect/scripts/mcp_client.py stream --progress-stdout \
  training.course.edit_ai_customer_chat \
  '{"courseId":<id>,"message":"<课程简报>","stream":true}'
```

脚本通过 stdout 输出 `💬` AI 话语 + `📊` 阶段标题 + 终态 JSON。首次使用需 `mcp_client.py auth`。

> 调用期间不做中途动作，等待终态 result。进度实时展示给客户端。
> 判定依据只有终态 result，不基于流中内容做决策。

**终态分流**：

- AI 提问 → 组织答案再调一次 chat（同一步骤，`stream:true`）
- AI 说计划供确认 → 发送 `"确认，开始生成"` 再调一次 chat
- error「结果不确定」→ **不重放** chat，直接进 Step 3 核实
- 秒拒 / 其他 error → 按 [异常排查](references/troubleshooting.md) 分流
- 本地超时/断流 ≠ 失败，服务端后台继续处理，直接进 Step 3 轮询

### Step 3：双完成判定

`course.get_ai_customer_config({"courseId":<id>})`

- `create_status_created` 且 `stages` 非空 → 建课完成，进 Step 4
- 否则（`prepare` / `streaming` / stages 为空）→ 每 30 秒轮询一次，**最长 20 分钟，全程静默不询问用户**；20 分钟仍未完成则向用户报告

### Step 4：生成练习链接

`task.create_open_project({"courseId":<id>})` → 拿到 link

### Step 5：交付

**同一条回复中**同时给出：

1. 可复制的纯文本链接
2. 二维码：`python3 <skill-root>/scripts/render_qr.py '<练习链接>'`

QR 生成失败时直接向用户展示原始练习链接，说明二维码步骤失败。

## 关键业务规则

1. **双完成判定**：`status: completed` 或 AI 回复文字不能证明课程建成；唯一判据是 `get_ai_customer_config` 返回 `create_status_created` 且 `stages` 非空。只信 config 字段值，不信 AI 回复文字。
2. **不重放**：`edit_ai_customer_chat` 发送成功后不得重试（可能触发会话保护锁死）；超时/断流/结果不确定时只通过轮询 `get_ai_customer_config` 核实状态。
3. **fileIds 原样传递**：用户已提供原始文档时，必须走 `file.upload_document` 上传整份文档，把 fileId 经 `metadata.fileIds` 附到 chat；禁止把文档内容摘录为纯文字经 message 传入。
4. **改课基线核实**：改课前先 `get_ai_customer_config` 记录各字段实际值（基线），改课后再次读取核实字段确实变化；不能只信 AI 自称"配置已满足要求"。
5. **链接 + 二维码双交付**：练习链接与二维码缺一不可，同一回复中交付；QR 生成失败时链接仍是有效交付。

## 技能文件结构

| 文件 | 功能 |
|---|---|
| `SKILL.md`（本文件） | 建课主流程 + 5 条关键业务规则 |
| `references/course-workflows.md` | 建课前准备、课程简报检查清单、改课 / 查询工作流、并发建课 |
| `references/result-and-progress.md` | 双完成判定详解、终态分流、进度通知语义、percent 语义 |
| `references/troubleshooting.md` | 错误码分流、超时预算、轮询兜底纪律、认证失败处理 |
| `references/file-upload.md` | 文档上传决策规则与步骤 |
| `scripts/render_qr.py` | QR 二维码渲染（宿主有 Python 运行时时使用） |
| `vendor/segno/` | QR 渲染依赖库（BSD-3 许可，随技能分发） |
