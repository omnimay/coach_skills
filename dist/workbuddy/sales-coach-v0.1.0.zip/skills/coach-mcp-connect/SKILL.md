---
name: coach-mcp-connect
description: 诊断 MCP 连接问题、管理 catalog、流式调用培训工具（建课/改课实时进度展示）
---

# MCP 连接诊断与流式调用

连接企业培训 MCP 服务器，排查连接问题、管理 catalog，或执行**流式工具调用**（建课/改课时实时展示进度）。服务器地址从包内 `mcp.json` 自动读取，适配不同环境。

> ⚠️ **`tools`/`registry_*` 命令**仅用于诊断连接问题和 catalog 管理。
> **`call`/`stream` 命令**可用于业务工具调用——尤其是 `stream --progress-stdout` 是建课/改课时
> 实时展示进度的首选路径（当宿主 MCP 客户端流式不可用时）。

## 何时使用

- 排查 MCP 连接问题（授权、网络、会话）
- 管理 catalog（查看/发布工具定义）
- 验证 MCP 服务器可达性
- **流式建课/改课**：通过 `stream --progress-stdout` 实时展示 AI 设计师处理进度
- **非流式工具调用**：通过 `call` 执行查询类工具

**`tools`/`registry_*`**：仅用于诊断和 catalog 管理，业务查询优先使用宿主 MCP 工具。
**`stream`**：建课/改课 chat 长调用（5-6 分钟），实时展示进度，用户不再面对空白等待。
**`call`**：短调用（查询课程列表等），自动注入 progressToken 接收通知。

## 前置条件

**Python 3.8+**（脚本依赖：纯 stdlib，无需 pip install）

## 快速开始

### 1. 授权登录

```bash
python3 <skill安装路径>/scripts/mcp_client.py auth
```

脚本会自动打开浏览器完成 OAuth 登录，token 自动保存到 `~/.config/coach-mcp-connect/tokens.json`。

**检查授权状态**：
```bash
python3 <skill安装路径>/scripts/mcp_client.py auth --status
```

**授权流程细节**：
- 自动打开浏览器（如无法自动打开，会打印 URL 供手动访问）
- 本地回调服务器自动监听授权回调（10 分钟超时）
- 端口冲突时自动尝试相邻端口（默认 8766）
- 回调超时后提供手动粘贴授权码的备选方案

**注意**：脚本内置 auto-refresh，每次调用工具时会自动检测 token 是否过期并尝试用 refresh_token 续期。只有 refresh_token 也失效时才需要重新执行 `auth`。

### 2. 列出可用工具（诊断）

```bash
python3 <skill安装路径>/scripts/mcp_client.py tools
```

此命令列出 MCP 服务器上可用的工具，用于验证连接和权限。

## 工具调用方式

**业务调用**：优先通过宿主 MCP 客户端（由宿主管理 OAuth 和会话）。

**脚本调用**：当宿主流式不可用（不发 progressToken / 硬超时 / UI 折叠），使用本脚本的 `call` 和 `stream` 命令。

### 非流式调用（`call`）

```bash
# 基本调用（进度通知走 stderr）
python3 <skill安装路径>/scripts/mcp_client.py call <tool_name> '<json_args>'

# 进度通知走 stdout（agent/Bash 工具捕获）
python3 <skill安装路径>/scripts/mcp_client.py call --progress-stdout <tool_name> '<json_args>'

# 示例：查询课程列表
python3 <skill安装路径>/scripts/mcp_client.py call training.course.list '{"categoryId":-1}'
```

`call` 自动注入 progressToken 接收通知；终态结果打印到 stdout，进度打印到 stderr（除非 `--progress-stdout`）。
遇 `isError: true` 时以退出码 1 结束。

### 流式调用（`stream`）—— 建课/改课首选

```bash
# 建课/改课的流式调用（实时展示 💬 AI 话语 / 📊 阶段标题）
python3 <skill安装路径>/scripts/mcp_client.py stream --progress-stdout \
  training.course.edit_ai_customer_chat \
  '{"courseId":123,"message":"创建药品销售课程","stream":true}'
```

`stream --progress-stdout` 效果：
- **stdout**：`💬` AI 话语 delta + `📊` 阶段标题（逐行实时渲染）+ 终态 JSON result（调用结束时一次性输出）
- **stderr**：状态行（`Streaming ...`）、摘要（通知数量/首帧时间戳）

额外选项：
- `--timeout N`：超时秒数（默认 660s，建课/改课给足 ≥ 600s）
- `--out PATH`：将全部通知以 JSONL 格式写入文件（供事后分析/排障）

不带 `--progress-stdout`（默认）：进度走 stderr，终态 JSON 走 stdout——适合 `2> progress.log > result.json` 分流落盘。

**通知消息形态**：

| 消息前缀 | 含义 | 显示 |
|---|---|---|
| `[message] ` | AI 助手话语 delta（实时预览） | `💬` + 内容 |
| 其他（如 `自动测试 5%`、`课程计划已生成`） | 阶段标题 | `📊` + 内容 |
| `请求已接受`（首帧） | 后端已受理 | `📊 请求已接受` |

**判定语义不变**：`stream` 仍是阻塞调用，agent 拿到的只有终态 result；课程是否创建成功仍由 `get_ai_customer_config` 判定（`status="create_status_created"` 且 `stages` 非空）。

## 端点

服务器地址从包内 `mcp.json` 自动解析，OAuth 端点从 MCP 地址派生：

|用途|URL 规则|
|---|---|
|MCP 通信|`mcp.json` 中 `mcpServers.<name>.url`|
|OAuth 元数据|`<base>/.well-known/oauth-authorization-server`|
|授权|`<base>/oauth/authorize`|
|Token|`<base>/oauth/token`|
|客户端注册|`<base>/oauth/register`|

其中 `<base>` = MCP URL 剥离尾部 `/mcp` 后的结果。例如：
- `https://example.com/coach/mcp` → `https://example.com/coach`
- `https://example.com/mcp` → `https://example.com`
- `https://example.com/prefix/mcp/` → `https://example.com/prefix`

可通过 `--mcp-url` 参数或 `MCP_URL` 环境变量覆盖自动检测的地址。

启用调试输出：`MCP_VERBOSE=1 python3 mcp_client.py auth` 会打印实际使用的 OAuth 端点。

## 管理 catalog

### 查看当前 catalog

```bash
python3 <skill安装路径>/scripts/mcp_client.py registry_get
```

### 发布 catalog（整个重发）

> ⚠️ **MCP 不允许单个工具更新**，必须整个 catalog 重发。流程：`registry_get` → 修改本地 tools 数组 → `registry_publish`。

```bash
python3 <skill安装路径>/scripts/mcp_client.py registry_publish '<catalog_json>' <expected_version>
```

`expectedVersion` 必须等于当前版本，否则冲突失败（乐观锁）。

## 参数命名约定

- **MCP 工具 inputSchema**：用 **camelCase**（给 LLM 看，符合前端习惯）
- **bodyParams 映射**：转 **snake_case** 给后端（后端只认 snake_case）
- **直接 curl 测试后端 API**：用 snake_case
- **通过 MCP 框架调用**：用 camelCase

## 默认参数陷阱

某些参数有默认值，不传会导致数据缺失：

|字段|工具|默认值陷阱|建议值|
|---|---|---|---|
|`source`|task_detail|默认 `h5` 漏掉 AI考官V2|`pc`|
|`categoryId`|course_list|默认 `0` 只返回未分类|`-1`（全部）|
|`isAdmin`|task_detail|默认行为不明确|`-1`（全部）|
|`category`|task_detail|默认 `0` 可能漏数据|`-1`（全部）|

**在工具 description 里加默认参数引导**：

```
**如果用户没有指定查询条件，建议默认使用以下参数**：categoryId=-1, orderField="create_at", orderType="descending"
```

## 返回字段语义差异

同一接口返回的字段可能名字相似但语义不同，要在工具 description 里区分：

```
projectName=任务名（网页显示），planName=课程名（两者可能不同）
```

反面案例：`projectName` vs `planName` 没说明 → LLM 输出时混淆 → 用户看到"同名任务"困惑。

## 排查清单

连不上 → 顺序检查：

1. **授权状态**：`python3 <skill安装路径>/scripts/mcp_client.py auth --status`
2. **元数据可达？** `GET /.well-known/oauth-authorization-server` 应返回 200
3. **token 换成功？** 脚本自动处理，检查 `~/.config/coach-mcp-connect/tokens.json`
4. **工具能调？** `python3 <skill安装路径>/scripts/mcp_client.py tools` 应返回工具列表

|现象|原因|解决|
|---|---|---|
|`401 invalid_token`|token 过期|脚本自动 refresh；若失败重新执行 `auth`|
|`上游服务拒绝了本次请求`|账号权限被下掉|联系管理员恢复权限|
|`405 Method Not Allowed`|管理接口用错域名|检查 `mcp.json` 中的 URL 是否正确|
|`400 invalid_request`（refresh_token）|多带了 `redirect_uri`|脚本已修复，严格只传 4 字段|

## 手动 OAuth 流程（备选）

如果脚本不可用，可手动执行 OAuth 流程：

### 1. 动态注册客户端

```bash
# 将 <MCP_BASE> 替换为 MCP URL 剥离尾部 /mcp 后的结果
# 例如 https://example.com/coach/mcp → https://example.com/coach
curl -X POST <MCP_BASE>/oauth/register \
  -H "Content-Type: application/json" \
  -d '{
    "client_name": "claude-code-session",
    "redirect_uris": ["http://127.0.0.1:8765/callback"],
    "grant_types": ["authorization_code", "refresh_token"],
    "response_types": ["code"],
    "token_endpoint_auth_method": "none"
  }'
```

返回 `client_id`（无 secret）。

### 2. 生成 PKCE 对

```python
import hashlib, base64, secrets

code_verifier = secrets.token_urlsafe(32)
code_challenge = base64.urlsafe_b64encode(
    hashlib.sha256(code_verifier.encode()).digest()
).rstrip(b'=').decode()
```

### 3. 拼授权 URL（浏览器打开）

```
<MCP_BASE>/oauth/authorize?
  response_type=code
  &client_id=<client_id>
  &redirect_uri=http://127.0.0.1:8765/callback
  &code_challenge=<code_challenge>
  &code_challenge_method=S256
  &state=<random_state>
  &resource=<MCP_URL>
```

> ⚠️ **必须带 **`resource`** 参数**，否则授权失败。

**操作流程**：
1. 把完整 URL 发给用户，提示："请在浏览器打开此链接登录授权"
2. 授权完成后浏览器会跳转到 `http://127.0.0.1:8765/callback?code=xxx`，页面会报错（因为本地没有服务），**请忽略报错**，把地址栏的完整 URL 复制粘贴给我
3. 从回调 URL 提取 `code` 参数

### 4. 用 code 换 token

```bash
curl -X POST <MCP_BASE>/oauth/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=authorization_code
      &code=<code>
      &client_id=<client_id>
      &redirect_uri=http://127.0.0.1:8765/callback
      &code_verifier=<code_verifier>
      &resource=<MCP_URL>"
```

返回 `access_token`（`at_xxx`）和 `refresh_token`（`rt_xxx`）。

### 5. 续期 token（refresh_token）

```bash
curl -X POST <MCP_BASE>/oauth/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=refresh_token
      &refresh_token=<rt_xxx>
      &client_id=<client_id>
      &resource=<MCP_URL>"
```

> ⚠️ **严格 4 字段**：`grant_type` / `refresh_token` / `client_id` / `resource`。**不能多带** `redirect_uri` / `code` / `code_verifier`，否则 400 `invalid_request`。

> 服务端会轮换 `refresh_token`，响应里的新 `rt_xxx` 必须更新到本地存储，旧的立刻失效。

## MCP 会话流程（手动）

如果需要手动管理 MCP 会话（不通过脚本）：

### 1. 初始化（拿 session-id）

```bash
curl -X POST <MCP_URL> \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "initialize",
    "params": {
      "protocolVersion": "2025-03-26",
      "capabilities": {},
      "clientInfo": {"name": "claude-code", "version": "1.0"}
    }
  }'
```

从响应头 `mcp-session-id` 拿 session ID（不是响应体里的）。

### 2. 发送 initialized 通知

```bash
curl -X POST <MCP_URL> \
  -H "Authorization: Bearer <access_token>" \
  -H "mcp-session-id: <session_id>" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "notifications/initialized"
  }'
```

### 3. 获取工具列表

```bash
curl -X POST <MCP_URL> \
  -H "Authorization: Bearer <access_token>" \
  -H "mcp-session-id: <session_id>" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/list"
  }'
```

### 4. 调用工具

```bash
curl -X POST <MCP_URL> \
  -H "Authorization: Bearer <access_token>" \
  -H "mcp-session-id: <session_id>" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "training.course_list",
      "arguments": {
        "categoryId": -1,
        "orderField": "create_at",
        "orderType": "descending",
        "page": 1,
        "pageSize": 10
      }
    }
  }'
```

响应是 `text/event-stream`，解析 `data:` 行里的 JSON。
